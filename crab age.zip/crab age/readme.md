#Crab Age Prediction

##Objective
Predict the age of crabs using machine learning

--

##Dataset
Crab Age Dataset

--

##Problem Type
Regression

--

##Machine Learning Models
-Decision Tree Regressor
-Random Forest Regressor

--

##Evaluation Metric
MAE

--

##Technologies
-Python
-Pandas
-Scikit-learn

--

##Workflow
1. Data Loading
2. Data Exploration
3. Data Cleaning
4. Feature Selection
5. Train/Test Split
6. Model Training
7. Prediction
8. Evaluation

--

##Results
| Model | MAE |
|-------|------|
| Decision Tree | 1.457184230220766 |
| Random Forest | 1.4628363852428024 |
